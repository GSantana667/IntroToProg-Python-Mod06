# ------------------------------------------------- #
# Title: Listing 3
# Description: Calling a function with multiple parameters
# ChangeLog: (Who, When, What)
# RRoot,1.1.2030,Created Script
# ------------------------------------------------- #

# Define the function
def AddValues(value1, value2):
    fltAnswer = value1 + value2 # Addition of values
    fltDifference = value1 - value2 # subtraction of values
    fltProduct = value1 * value2 # Multiplication of values
    fltQuotient = value1 / value2 # Division of values
    print("The Sum of the values is: " + str(fltAnswer))
    print("The Difference of the values is: " + str(fltDifference))
    print("The Product of the values is: " + str(fltProduct))
    print("The Quotient of the values is: " + str(fltQuotient))

# Call the function
AddValues(10, 5)
(input("Wanna do some math?"))