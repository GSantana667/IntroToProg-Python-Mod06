#-------------------------------------------------#
# Title: Listing 06
# Description: Returning multiple values as a tuple
# ChangeLog: (Who, When, What)
# GSantana, 08/12/2023, Created Script
#-------------------------------------------------#

# -- data code -- #
fltV1 = None  # first argument
fltV2 = None  # second argument
fltSum = None  # first result of processing
fltDiff = None  # second result of processing
fltProd = None  # third result of processing
fltQuot = None # Fourth result of processing
# -- processing code -- #
def Calculate(value1, value2): # Define the function
    sum = value1 + value2
    diff= abs(value1 - value2)
    prod = value1 * value2

    return sum, diff, prod, (value1 / value2)  # pack tuple

# -- presentation (I/0) code -- #
fltV1 = float(input("Enter value 1: "))
fltV2 = float(input("Enter value 2: "))
fltSum, fltDiff, fltProd, fltQuot = Calculate(fltV1, fltV2)  # unpack tuple
print("The Sum of %.2f and %.2f is %.2f" % (fltV1, fltV2, fltSum))
print("The Difference of %.2f and %.2f is %.2f" %(fltV1, fltV2, fltDiff))
print("The Product of %.2f and %.2f is %.2f" %(fltV1, fltV2, fltProd))
print("The Quotient of %.2f and %.2f is %.2f" %(fltV1, fltV2, fltQuot))